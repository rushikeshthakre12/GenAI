package com.RBU.project2.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.RBU.project2.entities.Task;
import com.RBU.project2.entities.User;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
	public User findByUserId(Long userId);
	
	public List<Task> findTaskByUserId(Long userId);
	
}

