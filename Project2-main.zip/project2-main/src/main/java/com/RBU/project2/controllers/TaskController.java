package com.RBU.project2.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.RBU.project2.entities.Task;
import com.RBU.project2.repositories.TaskRepository;
import com.RBU.project2.security.CustomUserDetails;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
	private TaskRepository taskRepository;
	public TaskController (TaskRepository taskRepository) {
		this.taskRepository = taskRepository;
	}

	@PostMapping("/save")
	public ResponseEntity<Task> createTask(@RequestBody Task task,
			@AuthenticationPrincipal CustomUserDetails userDetails) {
		task.setUserId(userDetails.getUserId());
		if (task.getStatus() == null) {
			task.setStatus("TODO");
		}
		taskRepository.save(task);
		return ResponseEntity.status(201).body(task);
		
	}
}
